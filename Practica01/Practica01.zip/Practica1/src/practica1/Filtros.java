/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * @Author Alexis Navarrete Puebla
 */
package practica1;

import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author Alexis Navarrete
 * Ésta clase contiene la implementación de los filtros requeridos
 */
public class Filtros{
    private final String image; 
    
    /**
     * Constructor
     * @param image - La imagen a la que le aplicaremos el filtro
     */
    public Filtros(String imagen){
        this.image = imagen;
    }
    
   
    /**
     * Éste método aplica el filtro de azar a la imagen
     * @return La imagen con el filtro azar aplicado
     * @throws IOException 
     */
    
    public Image random() throws IOException{
        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                int aux = buffImage.getRGB(i, j);
                Color color = new Color(aux);
                int rojo = (int) (Math.random() * 255-1);
                int verde = (int) (Math.random() * 255-1);
                int azul = (int) (Math.random() * 255-1);
                
                Color finalColor = new Color(rojo, verde, azul);               
                int pixel = finalColor.getRGB();

                buffImage.setRGB(i, j, pixel);    
              }
             }  
        Image img = (Image) buffImage;
        return img;        
    }
    
    
    /**
     * Éste método aplica el filtro tono de grises
     * Filtro 1 de tono de gris (r + g + b /3)
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image grisesMetodo1() throws IOException{
        //lectura  y carga de imagen

        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                int gris = (rojo+verde+azul)/3; //Obtenemos el tono de gris
                gris = Math.min(Math.max(gris, 0),255);
               
                Color finalColor = new Color(gris,gris,gris);
                int pixel = finalColor.getRGB();
                buffImage.setRGB(i, j, pixel); 
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    
    /**
     * Este método aplica tono de grises a la imagen
     * Filtro 2 de tono de gris R*0.3 + G*0.59 + B*0.11
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image grisesMetodo2() throws IOException{
        //lectura  y carga de imagen

        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                int gris = (int) Math.round(rojo*0.3 + verde*0.59 +azul*0.11); //Obtenemos el tono de gris
                gris = Math.min(Math.max(gris, 0),255);
                
                Color finalColor = new Color(gris,gris,gris);
                int pixel = finalColor.getRGB();
                buffImage.setRGB(i, j, pixel); 
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    
    /**
     * This method aplies the tonos de grises filter to an image
     * Filtro 3 de tono de gris desaturación
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image grisesMetodo3() throws IOException{
        //lectura  y carga de imagen
        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //iteramos pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                int gris = (Math.max(rojo,Math.max(verde, azul)) + Math.min(rojo,Math.min(verde, azul)))/2; 
                gris = Math.min(Math.max(gris, 0),255); 
                Color finalColor = new Color(gris,gris,gris);
                int pixel = finalColor.getRGB();
                buffImage.setRGB(i, j, pixel); 
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    
    /**
     * Éste filtro aplica el tono de grises a la imagen
     * Filtro 4 tono de gris Max RGB 
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image grisesMetodo4() throws IOException{
        //lectura  y carga de imagen
        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                int gris = Math.max(rojo,Math.max(verde, azul)); //Obtenemos el tono de gris
                //los valores no pueden pasar del rango entre 0 y 255
               
                Color finalColor = new Color(gris,gris,gris);
                int pixel = finalColor.getRGB();
                buffImage.setRGB(i, j, pixel); 
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    /**
     * Éste método aplica filtro tono de grises
     * La imagen con el filtro min RGB aplicado 
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image grisesMetodo5() throws IOException{
        //lectura  y carga de imagen
        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                int gris = Math.min(rojo,Math.min(verde, azul)); //Obtenemos el tono de gris
                //los valores no pueden pasar del rango entre 0 y 255
                Color finalColor = new Color(gris,gris,gris);
                int pixel = finalColor.getRGB();
                buffImage.setRGB(i, j, pixel); 
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    
    /**
     * Éste método aplica el filtro inverso a la imagen
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image inverso() throws IOException{
        //lectura  y carga de imagen

        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                double promedio = (rojo+verde+azul)/3; //promedio number of the rgb value
                if(promedio < 127){
                    Color finalColor = new Color(255,255,255);
                    int pixel = finalColor.getRGB();
                    buffImage.setRGB(i, j, pixel); 
                }else{
                    Color finalColor = new Color(0,0,0);
                    int pixel = finalColor.getRGB();
                    buffImage.setRGB(i, j, pixel); 
                }
                
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    
    /**
     * Éste filtro aplica el filtro de alto contraste a la imagen
     * obtenemos una imagen de blancos y negros  
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image altoContraste() throws IOException{
        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                double promedio = (rojo+verde+azul)/3; //promedio number of the rgb value
                //Otherwise, the pixels gets black
                if(promedio >=127){
                    Color finalColor = new Color(255,255,255);
                    int pixel = finalColor.getRGB();
                    buffImage.setRGB(i, j, pixel); 
                }else{
                    Color finalColor = new Color(0,0,0);
                    int pixel = finalColor.getRGB();
                    buffImage.setRGB(i, j, pixel); 
                }
                
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    
    
    /**
     * Método para aplicar rangos de filtros de RGB
     * La imagen resultante con el valor rgb deseado
     * @param r - valor del  rojo
     * @param g - valor del  verde
     * @param b - valor del  azul
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image rgb(int r,int g, int b) throws IOException{
        //Preparamos la imagen
        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed() & r;
                int verde = color.getGreen() & g;
                int azul = color.getBlue() & b;
                rojo = Math.max(Math.min(rojo, 255),0); 
                verde = Math.max(Math.min(verde, 255),0);
                azul = Math.max(Math.min(azul, 255),0);
                Color finalColor = new Color(rojo,verde,azul);
                int pixel = finalColor.getRGB();
                buffImage.setRGB(i, j, pixel); 
            }
        }
       Image img = (Image) buffImage;
       return img;
    }
}