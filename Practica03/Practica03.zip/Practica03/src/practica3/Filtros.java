/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * @Author Alexis Navarrete Puebla
 */
package practica3;

import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import javax.imageio.ImageIO;

/**
 *
 * @author Alexis Navarrete
 * Ésta clase contiene la implementación de los filtros requeridos
 */
public class Filtros{
    private final String image; 
    
    /**
     * Constructor
     * @param image - La imagen a la que le aplicaremos el filtro
     */
    public Filtros(String imagen){
        this.image = imagen;
    }
   
   /*
    Filtros de la práctica 01, bajar más para filtros de prácica 02
   */
    /**
     * Éste método aplica el filtro de azar a la imagen
     * @return La imagen con el filtro azar aplicado
     * @throws IOException 
     */
    //Método auxiliar 
   /**
     * Aplica el filtro de mosaico a la imagen
     * @param ancho ancho de la matriz
     * @param alto alto de la matriz
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    
    
    public BufferedImage mosaico(int ancho, int alto) throws IOException{
        if(ancho <=0 || alto<=0){
            throw new IOException("No puede ser menor a 0 el alto o ancho");
        }
        else{
            BufferedImage bI = null;
            File f = null;
            f = new File (image);
            bI = ImageIO.read(f);
            
            int tempAncho = bI.getWidth();
            int tempAlto = bI.getWidth();
            
            for(int i=0;i<tempAncho;i+=ancho){
                for(int j=0;j<tempAlto;j+=alto){
                    int x = i + ancho; 
                    int y = j + alto;
                    tempAncho  = ancho;
                    tempAlto = alto;
                    
                    if(x > tempAncho){
                        x = tempAncho;
                        tempAncho = tempAncho-1;
                    }
                    if(y > tempAlto){
                        y = tempAlto;
                        tempAlto = tempAlto -1;
                    }

                    int total = ancho*alto; 
                    int r = 0;
                    int g = 0;
                    int b = 0;
                    for(int k = i; k < x; k++){
                        for(int l = j; l < y; l++){
                            Color color = new Color(bI.getRGB(i, j));
                            r += color.getRed();
                            g += color.getGreen();
                            b += color.getBlue();
                        }
                    }
                    r = r/total;
                    g = g/total;
                    b = b/total;
                    for(int n = i; n < x; n++){
                        for(int m = j; m < y; m++){
                            Color finalColor = new Color(r,g,b);
                            int pixel = finalColor.getRGB();
                            bI.setRGB(n, m, pixel); 
                        }
                    }
                }
            }
        return bI;
        }   
    }
    
    
    

     
    public Image random() throws IOException{
        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                int aux = buffImage.getRGB(i, j);
                Color color = new Color(aux);
                int rojo = (int) (Math.random() * 255-1);
                int verde = (int) (Math.random() * 255-1);
                int azul = (int) (Math.random() * 255-1);
                
                Color finalColor = new Color(rojo, verde, azul);               
                int pixel = finalColor.getRGB();

                buffImage.setRGB(i, j, pixel);    
              }
             }  
        Image img = (Image) buffImage;
        return img;        
    }
    
    
    /**
     * Éste método aplica el filtro tono de grises
     * Filtro 1 de tono de gris (r + g + b /3)
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image grisesMetodo1() throws IOException{
        //lectura  y carga de imagen

        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                int gris = (rojo+verde+azul)/3; //Obtenemos el tono de gris
                gris = Math.min(Math.max(gris, 0),255);
               
                Color finalColor = new Color(gris,gris,gris);
                int pixel = finalColor.getRGB();
                buffImage.setRGB(i, j, pixel); 
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    
    
    
    /**
     * Este método aplica tono de grises a la imagen
     * Filtro 2 de tono de gris R*0.3 + G*0.59 + B*0.11
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image grisesMetodo2() throws IOException{
        //lectura  y carga de imagen

        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                int gris = (int) Math.round(rojo*0.3 + verde*0.59 +azul*0.11); //Obtenemos el tono de gris
                gris = Math.min(Math.max(gris, 0),255);
                
                Color finalColor = new Color(gris,gris,gris);
                int pixel = finalColor.getRGB();
                buffImage.setRGB(i, j, pixel); 
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    
    /**
     * This method aplies the tonos de grises filter to an image
     * Filtro 3 de tono de gris desaturación
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image grisesMetodo3() throws IOException{
        //lectura  y carga de imagen
        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //iteramos pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                int gris = (Math.max(rojo,Math.max(verde, azul)) + Math.min(rojo,Math.min(verde, azul)))/2; 
                gris = Math.min(Math.max(gris, 0),255); 
                Color finalColor = new Color(gris,gris,gris);
                int pixel = finalColor.getRGB();
                buffImage.setRGB(i, j, pixel); 
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    
    /**
     * Éste filtro aplica el tono de grises a la imagen
     * Filtro 4 tono de gris Max RGB 
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image grisesMetodo4() throws IOException{
        //lectura  y carga de imagen
        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                int gris = Math.max(rojo,Math.max(verde, azul)); //Obtenemos el tono de gris
                //los valores no pueden pasar del rango entre 0 y 255
               
                Color finalColor = new Color(gris,gris,gris);
                int pixel = finalColor.getRGB();
                buffImage.setRGB(i, j, pixel); 
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    /**
     * Éste método aplica filtro tono de grises
     * La imagen con el filtro min RGB aplicado 
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image grisesMetodo5() throws IOException{
        //lectura  y carga de imagen
        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                int gris = Math.min(rojo,Math.min(verde, azul)); //Obtenemos el tono de gris
                //los valores no pueden pasar del rango entre 0 y 255
                Color finalColor = new Color(gris,gris,gris);
                int pixel = finalColor.getRGB();
                buffImage.setRGB(i, j, pixel); 
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    
    /**
     * Éste método aplica el filtro inverso a la imagen
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image inverso() throws IOException{
        //lectura  y carga de imagen

        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                double promedio = (rojo+verde+azul)/3; //promedio number of the rgb value
                if(promedio < 127){
                    Color finalColor = new Color(255,255,255);
                    int pixel = finalColor.getRGB();
                    buffImage.setRGB(i, j, pixel); 
                }else{
                    Color finalColor = new Color(0,0,0);
                    int pixel = finalColor.getRGB();
                    buffImage.setRGB(i, j, pixel); 
                }
                
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    
    /**
     * Éste filtro aplica el filtro de alto contraste a la imagen
     * obtenemos una imagen de blancos y negros  
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image altoContraste() throws IOException{
        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                double promedio = (rojo+verde+azul)/3; //promedio number of the rgb value
                //Otherwise, the pixels gets black
                if(promedio >=127){
                    Color finalColor = new Color(255,255,255);
                    int pixel = finalColor.getRGB();
                    buffImage.setRGB(i, j, pixel); 
                }else{
                    Color finalColor = new Color(0,0,0);
                    int pixel = finalColor.getRGB();
                    buffImage.setRGB(i, j, pixel); 
                }
                
            }
        }
        Image img = (Image) buffImage;
        return img;
    }
    
    
    /**
     * Método para aplicar rangos de filtros de RGB
     * La imagen resultante con el valor rgb deseado
     * @param r - valor del  rojo
     * @param g - valor del  verde
     * @param b - valor del  azul
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image rgb(int r,int g, int b) throws IOException{
        //Preparamos la imagen
        BufferedImage buffImage = null;
        File f = null;
        f = new File (image);
        buffImage = ImageIO.read(f);
        int width = buffImage.getWidth();
        int height = buffImage.getHeight();
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(buffImage.getRGB(i, j));
                int rojo = color.getRed() & r;
                int verde = color.getGreen() & g;
                int azul = color.getBlue() & b;
                rojo = Math.max(Math.min(rojo, 255),0); 
                verde = Math.max(Math.min(verde, 255),0);
                azul = Math.max(Math.min(azul, 255),0);
                Color finalColor = new Color(rojo,verde,azul);
                int pixel = finalColor.getRGB();
                buffImage.setRGB(i, j, pixel); 
            }
        }
       Image img = (Image) buffImage;
       return img;
    }
    /*
    Filtros de la práctica 02, bajar más para los de la práctica 03
    Blur
    MotionBlur
    Bordes
    Sharpen
    Emboss
    PromedioMediano
    Se hace uso de las bibliotecas auxiliares Kernel y ConvolveOp
    Una operación de convolución le permite combinar los colores de un píxel de 
    origen y sus vecinos para determinar el color de un píxel de destino. 
    Esta combinación se especifica utilizando un núcleo (Kernel), un operador lineal
    que determina la proporción de cada color de píxel de origen utilizado para
    calcular el color de píxel de destino.
    */
    /**
     * Éste método aplica el filtro Blur a la imagen
     * @return la imagen con el filtro aplicado
     * @throws IOException si ocurre un error de entrada salida
     */
    public Image blur() throws IOException{
        //Debemos definir la matriz para el filtro 
        /*
            [0, 0, 1, 0, 0],
            [0, 1, 1, 1, 0],
            [1, 1, 1, 1, 1],
            [0, 1, 1, 1, 0],
            [0, 0, 1, 0, 0]
        
        */
        float tercio = 1f/13f;
        float[] matriz = {0,0,tercio,0,0,
                          0,tercio,tercio,tercio,0,
                          tercio,tercio,tercio,tercio,tercio,
                          0,tercio,tercio,tercio,0,
                          0,0,tercio,0,0}; 
        BufferedImage bI = null;
        File f = null;
        f = new File (image);
        bI = ImageIO.read(f);
        Kernel kernel = new Kernel (5,5,matriz);  //una matriz de 5x5
        ConvolveOp op = new ConvolveOp(kernel);  
        bI = op.filter(bI, null);//applies the convolution
        Image imagen = (Image) bI;
        return imagen;
    }
    
    /**
     * Este método aplica el filtro MotionBlur a la imagen
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image motionBlur() throws IOException{
        BufferedImage bI = null;
        File f = null;
        f = new File (image);
        bI = ImageIO.read(f);
        //Definimos la matriz para el filtro
        /*
            [1, 0, 0, 0, 0, 0, 0, 0,  0],
            [0, 1, 0, 0, 0, 0, 0, 0,  0],
            [0, 0, 1, 0, 0, 0, 0, 0,  0],
            [0, 0, 0, 1, 0, 0, 0, 0,  0],
            [0, 0, 0, 0, 1, 0, 0, 0,  0],
            [0, 0, 0, 0, 0, 1, 0, 0,  0],
            [0, 0, 0, 0, 0, 0, 1, 0,  0],
            [0, 0, 0, 0, 0, 0, 0, 1,  0],
            [0, 0, 1, 0, 0, 0, 0, 0,  1]
        
        */
        float noveno = 1f/9f;
        float[] matriz = {noveno,0,0,0,0,0,0,0,0,
                         0,noveno,0,0,0,0,0,0,0,
                         0,0,noveno,0,0,0,0,0,0,
                         0,0,0,noveno,0,0,0,0,0,
                         0,0,0,0,noveno,0,0,0,0,
                         0,0,0,0,0,noveno,0,0,0,
                         0,0,0,0,0,0,noveno,0,0,
                         0,0,0,0,0,0,0,noveno,0,
                         0,0,0,0,0,0,0,0,noveno}; 
        Kernel kernel = new Kernel(9,9,matriz);  //una matriz de 9x9
        ConvolveOp op = new ConvolveOp(kernel); 
        bI = op.filter(bI, null); 
        Image imagen = (Image) bI;
        return imagen;
    }
    
    /**
     * Éste método aplica el filtro de encontrar bordes a la imagen
     * @return la imagen con el filtro aplicado
     * @throws IOException 
     */
    public Image encontrarBordes() throws IOException{
        BufferedImage bI = null;
        File f = null;
        f = new File (image);
        bI = ImageIO.read(f);
        //Usaremos ésta matriz para poder detectar todos los marcos en todas las
        //direcciones de la imagen
        /*
        Definimos la matriz necesaria para el filtro
            [-1, -1, -1],
            [-1,  8  -1],
            [-1, -1, -1]
        */
        float[] matrix = {-1,-1,-1,
                          -1,8,-1,
                          -1,-1,-1}; 
        Kernel kernel = new Kernel(3,3,matrix); //una matriz de 3x3
        ConvolveOp op = new ConvolveOp(kernel);
        bI = op.filter(bI, null);
        Image imagen = (Image) bI;
        return imagen;
    }
    
    /**
     * Éste método aplica el filtro sharpen a la imagen
     * @return la imagen con el filtro aplicado
     * @throws IOException 
     */
    /*
    El resultado será una nueva imagen donde se mejoran los bordes,
    haciendo que se vea más nítida.
    La adición de esas dos imágenes se realiza tomando el filtro de detección de bordes
    del método anterior e incrementando el valor central de este con 1. 
    
    */
    public Image sharpen() throws IOException{
        BufferedImage bI = null;
        File f = null;
        f = new File (image);
        bI = ImageIO.read(f);
        /*
        Definimos la matriz (kernel) necesaria para el filtro
            [-1, -1, -1],
            [-1,  9, -1],
            [-1, -1, -1]
        */
        float[] matrix = {-1,-1,-1,
                          -1,9,-1,
                          -1,-1,-1};
        Kernel kernel = new Kernel(3,3,matrix); //una matriz de 3x3
        ConvolveOp op = new ConvolveOp(kernel);
        bI = op.filter(bI, null);
        Image img = (Image) bI;
        return img;
    }
    
    /**
     * Éste método aplica el filtro emboss a la imagen
     * @return la imagen con el filtro aplicado
     * @throws IOException 
     */
    /*
    El filtro da un efecto de sombra 3D a la imagen
    */
    public Image emboss() throws IOException{
        BufferedImage bI = null;
        File f = null;
        f = new File (image);
        bI = ImageIO.read(f);
        /*
        Definimos la matriz (kernel) necesaria para el filtro
            [-1, -1, 0],
            [-1,  0, 1],
            [ 0,  1, 1]
        */
        float[] matrix = {-1,-1,0,
                          -1,0,1,
                          0,1,1}; 
        Kernel kernel = new Kernel(3,3,matrix);//Matriz de 3x3
        ConvolveOp op = new ConvolveOp(kernel);
        bI = op.filter(bI, null);
        Image img = (Image) bI;
        return img;
    }
    //Método auxiliar para filtro mediana
    
    
    private static int auxMediana(int[] arreglo) {
        int m = -1;
        for (int i = 0, n = 0; i <= (arreglo.length / 2); i++, n = i) {
            for (int k = i + 1; k < arreglo.length; k++){
                if(arreglo[n] > arreglo[k]) 
                    n = k;
            }
            m = arreglo[n];
            arreglo[n] = arreglo[i];
            arreglo[i] = m;
        }
        //comprobamos si la longitud es par
        if((arreglo.length % 2) == 0) 
            return (m + arreglo[arreglo.length / 2 - 1]) / 2;
        return m;
    }
    
    
    
    /**
     * Filtro de convolucion mediana de imagen 
     * @return la imagen con el filtro aplicado
     * @throws java.io.IOException
     */
    
    
    /*
    Se visita cada píxel de la imagen y se reemplaza por la mediana de
    los píxeles vecinos. 
    
    */
    public Image mediana() throws IOException {
        
        BufferedImage bI = null;
        File f = null;
        f = new File (image);
        bI = ImageIO.read(f);
        //Obtenemos alto y ancho de la imagen con los métodos de BufferedImage
        int wid = bI.getWidth();
        int hei = bI.getHeight();
        int tamanio = 3;
        //arreglos auxiliares para guardar los colores 
        Color[][] colorOriginal = new Color[wid][hei];
        for (int x = 0; x < wid; x++) {
            for (int y = 0; y < hei; y++){
                //guardamos los colores para cada pixel de la imagen
                colorOriginal[x][y] = new Color(bI.getRGB(x, y));
            } 
                
        }
        
        int red[];
        int green[];
        int blue[];
        //Iterando cada pixel para asignarle el nuevo color 
        int rad = tamanio/2;
        
        for (int x = 0; x < wid; x++) {
            int xIni = 0;
            int xFin = 0;
            
            if(x < rad)
                xIni = rad-x;
            else
                xIni = 0;
            
            if((wid - x) <= rad)
                xFin = rad + wid - x;
            else
                xFin=tamanio;
            
            for (int y = 0; y < hei; y++){
                int yIni = 0;
                int yFin = 0;
                
                if(y < rad)
                    yIni = rad - y;
                
                else
                    yIni = 0;
                
                if((hei - y) <= rad)
                    yFin = rad + hei - y;
                    
                else
                    yFin = tamanio;
                
                //Calcular la media de cada componente
                red = new int[(xFin - xIni) * (yFin - yIni)]; 
                green = new int[red.length]; 
                blue = new int[red.length];
                for (int i = 0, px = x - rad; (i + xIni) < xFin; i++) {
                    for (int j = 0, py = y - rad; (j + yIni) < yFin; j++) {
                        red[j + (yFin - yIni) * i] = colorOriginal[px + i + xIni][py + j + yIni].getRed();
                        green[j + (yFin - yIni) * i] = colorOriginal[px + i + xIni][py + j + yIni].getGreen();
                        blue[j + (yFin - yIni) * i] = colorOriginal[px + i + xIni][py + j + yIni].getBlue();
                    }
                }
                bI.setRGB(x, y, new Color(auxMediana(red),
                                  auxMediana(green),
                                  auxMediana(blue)).getRGB());
            }
        } 
        Image imagen = (Image) bI;
        return imagen;
        }
        
        
   public Image promedio() throws IOException 
   {
     Color[] vecinos = {null,null,null,
                          null,null,null,
                          null,null,null};
      BufferedImage bI = null;
      File f = null;
      f = new File (image);
      bI = ImageIO.read(f);
      int wid = bI.getWidth();
      int hei = bI.getHeight();
      for(int i = 1; i< wid-1;i++){
          for(int j = 1; j< hei-1; j++){
              
              Color color0 = new Color(bI.getRGB(i-1, j-1));
              vecinos[0] = color0;
              Color color1 = new Color(bI.getRGB(i-1, j));
              vecinos[1] = color1;
              
              Color color2 = new Color(bI.getRGB(i-1, j+1));
              vecinos[2] = color2;
              
              Color color3 = new Color(bI.getRGB(i, j-1));
              vecinos[3] = color3;
              
              Color color4 = new Color(bI.getRGB(i, j));
              vecinos[4] = color4;
              
              Color color5 = new Color(bI.getRGB(i, j+1));
              vecinos[5] = color5;
              Color color6 = new Color(bI.getRGB(i+1, j-1));
              vecinos[6] = color6;
              Color color7 = new Color(bI.getRGB(i+1, j));
              vecinos[7] = color7;
              Color color8 = new Color(bI.getRGB(i+1, j+1));
              vecinos[8] = color8;
              float promR;
              float promG;
              float promB;
              for(int x = 0; x < vecinos.length ; x++){
                promR = vecinos[x].getRed();
                promG = vecinos[x].getGreen();
                promB = vecinos[x].getBlue();
                int auxPromR = (int)(promR/vecinos.length);
                int auxPromG = (int)(promG/vecinos.length);
                int auxPromB = (int)(promB/vecinos.length);
                bI.setRGB(i, j, new Color(auxPromR,auxPromG, auxPromB).getRGB());
              }
          }  
        }
        Image imagen = (Image) bI;
        return imagen;
      }
    //Métodos de la práctica 03 
   
   /**
     * This method aplies the colores sin letra filter to an image
     * La imagen resultante solo tiene letras M con el color correspondiente 
     * @param x 
     * @param y 
     * @param lSize 
     * @throws IOException 
     */
    public void coloresLetraM(int x, int y,int tamanioLetra) throws IOException{
        BufferedImage bI = mosaico(x,y); //mosaico filter applied
        BufferedWriter bw = null;
        try{
            
            FileWriter file = new FileWriter("../Imagen01.html",false); 
            bw = new BufferedWriter(file);
            int width = bI.getWidth();
            int height = bI.getHeight();
            //int r, g, b;
            //Iterating pixel by pixel
            for(int i = 0; i<height; i++){
                for(int j = 0; j<width; j++){
                    Color color = new Color(bI.getRGB(j, i));
                    int r = color.getRed();
                    int g =  color.getGreen();
                    int b = color.getBlue();
                    //Escribimos el código html estilo y definimos el tamaño de la letra
                    //con los tags html
                    bw.write("<font size="+tamanioLetra+" style=color:rgb("+r+","+g+","+b+");>M</font>"); //Código HTML
                }
                bw.write("<br>"); 
            }
        }catch(IOException e){
            System.err.println("Error: " + e.getMessage());
        }finally{
            if(bw!=null){
                bw.close();
            }
        }
    }
    //Método auxiliar para escala de grises de la práctica 1 adaptado
    /**
     * Éste método aplica el filtro tono de grises
     * Filtro 1 auxiliar para práctica 3 de tono de gris (r + g + b /3)
     * @return La imagen con el filtro aplicado
     * @throws IOException 
     */
    public BufferedImage grisesMetodo1Aux(BufferedImage bI) throws IOException{
        //lectura  y carga de imagen

        int width = bI.getWidth();
        int height = bI.getHeight();
        //Iterando pixel a pixel
        for(int i = 0; i<width; i++){
            for(int j = 0; j<height; j++){
                Color color = new Color(bI.getRGB(i, j));
                int rojo = color.getRed();
                int verde = color.getGreen();
                int azul = color.getBlue();
                int gris = (rojo+verde+azul)/3; //Obtenemos el tono de gris
                gris = Math.min(Math.max(gris, 0),255);
               
                Color finalColor = new Color(gris,gris,gris);
                int pixel = finalColor.getRGB();
                bI.setRGB(i, j, pixel); 
            }
        }
        return bI;
    }
    /**
     * Éste método aplica el filtro de M tonos de grises
     * Escribe un archivo html con la imagen resultante y puras letras M con grises
     * @param ancho
     * @param alto
     * @param tamanioLetra
     * @throws IOException 
     */
    public void grisesLetraM(int ancho, int alto,int tamanioLetra) throws IOException{
        
         
        BufferedWriter bw = null;
        try{
            BufferedImage bI = mosaico(ancho,alto); 
            bI = grisesMetodo1Aux(bI);
            FileWriter file = new FileWriter("../Imagen02.html",false);
            bw = new BufferedWriter(file);
            int anchoAux = bI.getWidth();
            int altoAux = bI.getHeight();
            int r;
            for(int i = 0; i<altoAux; i++){
                for(int j = 0; j<anchoAux; j++){
                    Color color = new Color(bI.getRGB(j, i)); //Color auxiliar
                    r = color.getRed();
                    //Escribimos el código html estilo y definimos el tamaño de la letra
                    //con los tags html
                    bw.write("<font size="+tamanioLetra+" style=color:rgb("+r+","+r+","+r+");>M</font>");
                }
                bw.write("<br>");
            }
        }catch(IOException e){
            System.err.println("Ocurrió un error de lectura escritura: " + e.getMessage());
        }finally{
            if(bw!=null){
                bw.close();
            }
        }
    }
    
    /**
     * Éste método aplica el filtro MNHHQ...letras que simulan tonos de gris (color)
     * Escribe un archivo html con la imagen resultado con las letras correspondientes
     * @param ancho
     * @param alto
     * @param tamanioLetra
     * @throws IOException 
     */
    public void letrasGris(int ancho, int alto,int tamanioLetra) throws IOException{
         
        BufferedWriter bw = null;
        try{
            BufferedImage bI = mosaico(ancho,alto);
            FileWriter file = new FileWriter("../Imagen03.html",false);
            bw = new BufferedWriter(file);
            
            int anchoAux = bI.getWidth();
            int altoAux = bI.getHeight();
            //Iterating pixel by pixel
            int r, g, b;
            for(int i = 0; i<altoAux; i++){
                for(int j = 0; j<anchoAux; j++){
                    Color color = new Color(bI.getRGB(j, i));
                    r = color.getRed();
                    g = color.getGreen();
                    b = color.getBlue();
                    int gris = (r+g+b)/3;
                    String letra = buscaLetra(gris);
                    //Escribimos el código html estilo y definimos el tamaño de la letra
                    //con los tags html
                    bw.write("<font size="+tamanioLetra+" style=color:rgb("+r+","+g+","+b+");>"+letra+"</font>");
                }
                bw.write("<br>");//Salto de linea
            }
        }catch(IOException e){
            System.err.println("Ocurrió un error de lectura escritura: " + e.getMessage());
        }finally{
            //Cerramos el buffer
            if(bw!=null){
                bw.close();
            }
        }
    }
    
    
    
    
    
        
    
    /**
     * Método auxiliar proporcionado para determinar letra de gris
     * 00..15          : Letra := 'M';    {MNH#QUAD0Y2$%+. }
        16..31          : Letra := 'N';
        32..47          : Letra := 'H';
        48..63          : Letra := '#';
        64..79          : Letra := 'Q';
        80..95          : Letra := 'U';
        96..111         : Letra := 'A';
        112..127        : Letra := 'D';
        128..143        : Letra := '0';
        144..159        : Letra := 'Y';
        160..175        : Letra := '2';
        176..191        : Letra := '$';
        192..209        : Letra := '%';
        210..225        : Letra := '+';
        226..239        : Letra := '.';
        240..255        : Letra := ' ';
  end{Case tonos de gris}
     */
    private String buscaLetra(int gris){
        String letra = " ";
        
        if(gris<16){
            letra = "M";
        }else if(gris>=16 && gris<32){
            letra = "N";
        }else if(gris>31 && gris<48){
            letra = "H";
        }else if(gris>47 && gris<64){
            letra = "#";
        }else if(gris>63 && gris<80){
            letra = "Q";
        }else if(gris>79 && gris<96){
            letra = "U";
        }else if(gris>95 && gris<112){
            letra = "A";
        }else if(gris>111 && gris<128){
            letra = "D";
        }else if(gris>127 && gris<144){
            letra = "0";
        }else if(gris>143 && gris<160){
            letra = "Y";
        }else if(gris>159 && gris<176){
            letra = "2";
        }else if(gris>175 && gris<192){
            letra = "$";
        }else if(gris>191 && gris<210){
            letra = "%";
        }else if(gris>209 && gris<226){
            letra = "+";
        }else if(gris>225 && gris<240){
            letra = ".";
        }
        return letra;
    }
    
    /**
     * Método que aplica poner filtro texto en imagen 
     * @param ruta del archivo de texto de entrada
     * @param ancho 
     * @param alto
     * @param tamanioLetra 
     * @throws IOException 
     */
    public void coloresTextoImagen(String ruta,int ancho, int alto,int tamanioLetra) throws IOException{
        
        
        BufferedWriter bw = null;
        try{
            BufferedImage bI = mosaico(ancho,alto); //
            //Estructura de datos auxiliar
            Queue<Character> cola = new LinkedList<>();
            BufferedReader bf = new BufferedReader(new FileReader(ruta)); 
            //Lectura y guardado de archivo
            List<String> lines = new ArrayList<>(); 
            String line;
            while((line = bf.readLine()) != null){
                for(String s : line.split(" ")){
                    lines.add(s); 
                }
            }
            bf.close();
            //Guardamos los caraceteres del texto
            List<Character> chars = new ArrayList<>();
            for(String cadena : lines){
                for(char caract : cadena.toCharArray()){
                    chars.add(caract); 
                }
            }
            //Añadimos a la cola los caracteres
            for(char caracter : chars){
                cola.add(caracter); 
            }
            //Escritura del archivo
            FileWriter file = new FileWriter("../Imagen06.html",false);
            bw = new BufferedWriter(file);
            int anchoAux = bI.getWidth();
            int altoAux = bI.getHeight();
            int r, g, b;
            for(int i = 0; i<altoAux; i++){
                for(int j = 0; j<anchoAux; j++){
                    char letra = cola.poll(); 
                    //Obtenemos el rgb del pixel
                    Color color = new Color(bI.getRGB(j, i));
                    r = color.getRed();
                    g = color.getGreen();
                    b = color.getBlue();
                    //Código html de escritura estilo y tamaño de letra
                    bw.write("<font size="+tamanioLetra+" style=color:rgb("+r+","+g+","+b+");>"+letra+"</font>");
                    cola.add(letra);
                }
                bw.write("<br>");
            }
        }catch(IOException e){
            System.err.println("Error de escritua o lectura: " + e.getMessage());
        }finally{
            //cerramos el buffer
            if(bw!=null){
                bw.close();
            }
        }
    }
    

    /*
     * Aplica el filtro dominó blancas
     * @param ancho 
     * @param alto 
     * @param tamanioLetra 
     * @throws IOException 
     */
    public void dominoBlancas(int ancho, int alto,int tamanioLetra) throws IOException{
        
        BufferedWriter bw = null;
        try{
            BufferedImage bI = mosaico(ancho,alto); 
            bI = grisesMetodo1Aux(bI);
            FileWriter file = new FileWriter("../Imagen07.html",false);//Open the file
            bw = new BufferedWriter(file);
            int width = bI.getWidth();
            int height = bI.getHeight();
             bw.write("<PRE><style>@font-face{font-family: 'Playcrds';"
                     + "src: url('../dominos-cartas/lasvwd__.TTF') "
                     + "format('truetype');}font{font-family: 'Playcrds'}</style>"); 
            int r, g, b;
            for(int i = 0; i<height; i++){
                for(int j = 0; j<width; j++){
                    Color color = new Color(bI.getRGB(j, i));
                    r = color.getRed();
                    g = color.getGreen();
                    b = color.getBlue();
                    int gris = (r+g+b)/3;
                    String letra = encuentraDominoBlanco(gris);
                    //Escribimos el código html donde definimos el tamaño de la letra
                    //con los tags html
                    bw.write("<font size="+tamanioLetra+">"+letra+"</font>");
                }
                bw.write("<br>");
            }
        }catch(IOException e){
            System.err.println("Ocurrió un error de lectura escritura: " + e.getMessage());
        }finally{
            //cerramos el buffer
            if(bw!=null){
                bw.close();
            }
        }
    }
    
    /**
     * Selecciona el valor de domino del pixel
     * @param gris valor del color gris
     * @return el valor del pixel
     */
    /*
    procedure SeleccionaDomino(NumColor : LongInt;
                           IzqDer   : char); //fichas blancas, puntos negros
    begin
      if IzqDer = 'I' then
      Case NumColor of
           0..36     : Letra := '6';
           37..72    : Letra := '5';
           73..108   : Letra := '4';
           109..144  : Letra := '3';
           145..180  : Letra := '2';
           181..216  : Letra := '1';
           217..255  : Letra := '0';
      end; {Case}
      if IzqDer = 'D' then
      Case NumColor of
           0..36     : Letra := '^';
           37..72    : Letra := '%';
           73..108   : Letra := '$';
           109..144  : Letra := '#';
           145..180  : Letra := '@';
           181..216  : Letra := '!';
           217..255  : Letra := ')';
      end {Case}
        end;
    */
    private String encuentraDominoBlanco(int gris){
        String letra = "0)";
        if(gris<37){
            letra = "6^";
        }else if(gris>=37 && gris<73){
            letra = "5%";
        }else if(gris>72 && gris<109){
            letra = "4$";
        }else if(gris>108 && gris<145){
            letra = "3#";
        }else if(gris>144 && gris<181){
            letra = "2@";
        }else if(gris>180 && gris<217){
            letra = "1!";
        }
        return letra;
    }
    
    
     /**
     *Éste método aplica el filtro Dominó negro a la imagen
     * @param ancho 
     * @param alto 
     * @param tamanioLetra 
     * @throws IOException 
     */
    public void dominoNegro(int ancho, int alto,int tamanioLetra) throws IOException{
        BufferedWriter bw = null;
        try{
            BufferedImage bI = mosaico(ancho,alto); 
            bI = grisesMetodo1Aux(bI);
            FileWriter file = new FileWriter("../Imagen08.html",false);
            bw = new BufferedWriter(file);
            int auxAncho = bI.getWidth();
            int auxAlto = bI.getHeight();
             bw.write("<PRE><style>@font-face{font-family: 'Playcrds';"
                     + "src: url('../dominos-cartas/lasvbld_.TTF') "
                     + "format('truetype');}font{font-family: 'Playcrds'}</style>");
             int r, g, b;
            for(int i = 0; i<auxAlto; i++){
                for(int j = 0; j<auxAncho; j++){
                    Color color = new Color(bI.getRGB(j, i));
                    r = color.getRed();
                    g = color.getGreen();
                    b = color.getBlue();
                    int gray = (r+g+b)/3;
                    String letra = encuentraDominoNegro(gray);
                    //Escribimos el código html donde definimos el tamaño de la letra
                    //con los tags html
                    bw.write("<font size="+tamanioLetra+">"+letra+"</font>");
                }
                bw.write("<br>");
            }
        }catch(IOException e){
            System.err.println("Ocurrió un error de lectura escritura: " + e.getMessage());
        }finally{
            //cerramos el buffer
            if(bw!=null){
                bw.close();
            }
        }
    }
     /**
     * Busca el valor de domino del pixel 
     * @param gris valor del color gris
     * @return el valor del pixel
     */
    
    /*
    procedure SeleccionaDominoNegro(NumColor : LongInt;
                                IzqDer   : char); //fichas blancas, puntos negros

        begin
      if IzqDer = 'I' then
      Case NumColor of
           0..36     : Letra := '0';
           37..72    : Letra := '1';
           73..108   : Letra := '2';
           109..144  : Letra := '3';
           145..180  : Letra := '4';
           181..216  : Letra := '5';
           217..255  : Letra := '6';
      end; {Case}
      if IzqDer = 'D' then
      Case NumColor of
           0..36     : Letra := ')';
           37..72    : Letra := '!';
           73..108   : Letra := '@';
           109..144  : Letra := '#';
           145..180  : Letra := '$';
           181..216  : Letra := '%';
           217..255  : Letra := '^';
      end {Case}
    end;
    
    */
    private String encuentraDominoNegro(int gris){
        String letra = "6^";
        if(gris<37){
            letra = "0)";
        }else if(gris>=37 && gris<73){
            letra = "1!";
        }else if(gris>72 && gris<109){
            letra = "2@";
        }else if(gris>108 && gris<145){
            letra = "3#";
        }else if(gris>144 && gris<181){
            letra = "4$";
        }else if(gris>180 && gris<217){
            letra = "5%";
        }
        return letra;
    }
    
    /**
     * Aplica el filtro naipes
     * @param ancho Width of the mosaic
     * @param alto Height of the mosaic
     * @param tamanioLetra Size of the letra
     * @throws IOException 
     */
    
    /*
    procedure SeleccionaCarta(NumColor : LongInt);
begin
  Case NumColor of
        00..20          : Letra := 'M';    //mas oscuro
        21..40          : Letra := 'L';
        41..60          : Letra := 'K';
        61..80          : Letra := 'J';
        81..100         : Letra := 'I';
        101..120        : Letra := 'H';
        121..140        : Letra := 'G';
        141..160        : Letra := 'F';
        161..180        : Letra := 'E';
        181..200        : Letra := 'D';
        201..220        : Letra := 'C';
        221..240        : Letra := 'B';
        241..255        : Letra := 'A';   //mas claro
  end{Case tonos de gris}
end;
    */
    public void naipes(int ancho, int alto,int tamanioLetra) throws IOException{
        BufferedImage bI = mosaico(ancho,alto); //mosaico filter applied
        bI = grisesMetodo1Aux(bI);
        BufferedWriter bw = null;
        try{
            FileWriter file = new FileWriter("../Imagen09.html",false);
            bw = new BufferedWriter(file);
            int width = bI.getWidth();
            int height = bI.getHeight();
             bw.write("<PRE><style>@font-face{font-family: 'Playcrds';"
                     + "src: url('../dominos-cartas/Playcrds.TTF') "
                     + "format('truetype');}font{font-family: 'Playcrds'}</style>"); 
            
            int r, g, b;
            for(int i = 0; i<height; i++){
                for(int j = 0; j<width; j++){
                    //Obtenemos el rgb del pixel 
                    Color color = new Color(bI.getRGB(j, i));
                    r= color.getRed();
                    g = color.getGreen();
                    b = color.getBlue();
                    int gris = (r+g+b)/3;
                    String letra = encuentraCarta(gris);
                    
                    //Escribimos el código html donde definimos el tamaño de la letra
                    //con los tags html
                    bw.write("<font size="+tamanioLetra+">"+letra+"</font>");
                }
                bw.write("<br>"); 
            }
        }catch(IOException e){
            System.err.println("Ocurrió un error de lectura escritura: " + e.getMessage());
        }finally{
            //Cerramos el buffer
            if(bw!=null){
                bw.close();
            }
        }
    }
    
    /**
     * Regresa la carta correspondiente al pixel
     * @param gris, el valor de gris
     * @return la letra de la carta correspondiente
     */
    private String encuentraCarta(int gris){
        String letra = "A";
        if(gris<21){
            letra = "M";
        }else if(gris>=21 && gris<41){
            letra = "L";
        }else if(gris>40 && gris<61){
            letra = "K";
        }else if(gris>60 && gris<81){
            letra = "J";
        }else if(gris>80 && gris<101){
            letra = "I";
        }else if(gris>100 && gris<121){
            letra = "H";
        }else if(gris>120 && gris<141){
            letra = "G";
        }else if(gris>140 && gris<161){
            letra = "F";
        }else if(gris>160 && gris<181){
            letra = "E";
        }else if(gris>180 && gris<201){
            letra = "D";
        }else if(gris>200 && gris<221){
            letra = "C";
        }else if(gris>220 && gris<241){
            letra = "B";
        }
        return letra;
    }
    
   }
    
    
    
    